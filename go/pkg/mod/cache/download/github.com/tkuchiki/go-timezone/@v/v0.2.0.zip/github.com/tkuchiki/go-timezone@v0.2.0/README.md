# go-timezone

Timezone utility for Go

[![GoDocWidget]][GoDocReference]

[GoDocWidget]:https://godoc.org/github.com/tkuchiki/go-timezone?status.svg
[GoDocReference]:https://godoc.org/github.com/tkuchiki/go-timezone

![Test](https://github.com/tkuchiki/go-timezone/workflows/Test/badge.svg)

## Data source

https://github.com/tkuchiki/timezones

# Contributors

- [@alex-tan](https://github.com/alex-tan)
- [@kkavchakHT](https://github.com/kkavchakHT)
- [@scottleedavis](https://github.com/scottleedavis)
- [@sashabaranov](https://github.com/sashabaranov)
